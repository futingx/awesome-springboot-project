package org.example.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.*;
import org.example.pojo.BookInfo;

import java.util.List;

/**
 * 项目:firstObjectMaven
 * 描述: 统一响应类
 * 时间:2024/6/17 14:47
 * 作者:付庭喜
 * 版本:1.0
 **/

@Mapper()//1.表示这是一个数据层2.实现了这个接口的实现类和对象

public interface BookInfoDao extends BaseMapper<BookInfo> {
    //演示如何自定义接口
    @Select("select * from book_info")
    List<BookInfo> query();

//     // 新增用户信息
//    @Insert("INSERT INTO book_info (book_id, title, author,publisher,publication_year,genre,total_copies,available_copies,description) VALUES (#{bookInfo.bookId}, #{bookInfo.title}, #{bookInfo.author},#{bookInfo.publisher},#{bookInfo.publication_year},#{bookInfo.genre},#{bookInfo.total_copies},#{bookInfo.available_copies},#{bookInfo.description})")
//    Integer add(BookInfo bookInfo);
//
//    // 更新用户信息
//    @Update("UPDATE book_info SET title = #{BookInfo.title}, author = #{BookInfo.author} WHERE book_id = #{BookInfo.bookId}")
//    Integer update();
//
//    // 删除用户信息
//    @Delete("DELETE FROM book_info WHERE id = #{BookInfo.bookId}")
//    Integer delete();
}
