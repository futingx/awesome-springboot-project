package org.example.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.example.pojo.BorrowInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * @version 1.0
 * @Author 付庭喜
 * @Date 2024/7/25 下午7:12
 * @注释:
 **/
@Mapper
public interface BorrowInfoDao extends BaseMapper<BorrowInfo> {

    @Select("select * from borrow")
    List<BorrowInfo> bookquery();

}
