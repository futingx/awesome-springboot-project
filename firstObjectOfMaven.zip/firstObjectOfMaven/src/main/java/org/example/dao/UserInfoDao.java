package org.example.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.*;
import org.example.pojo.UserInfo;

import java.util.List;

/**
 * 项目:firstObjectMaven
 * 描述: 统一响应类
 * 时间:2024/6/17 14:47
 * 作者:付庭喜
 * 版本:1.0
 **/

@Mapper()//1.表示这是一个数据层2.实现了这个接口的实现类和对象
//单表操作全部实现
public interface UserInfoDao extends BaseMapper<UserInfo> {

    //演示如何自定义接口
    @Select("select * from user_info")
    List<UserInfo> query();

     // 新增用户信息
    @Insert("INSERT INTO user_info (user_id, user_name, age,sex) VALUES (#{userInfo.userId}, #{userInfo.userName}, #{userInfo.age},#{userInfo.sex})")
    Integer add(UserInfo userInfo);

    // 更新用户信息
    @Update("UPDATE user_info SET user_id = #{UserInfo.userId}, user_name = #{UserInfo.userName}, age = #{UserInfo.age},sex = #{UserInfo.sex} WHERE id = #{UserInfo.userId}")
    Integer update();

    // 删除用户信息
    @Delete("DELETE FROM userInfo WHERE id = #{UserInfo.userId}")
    Integer delete();

}
