package org.example.dto;

import lombok.Data;

/**
 * @version 1.0
 * @Author 付庭喜
 * @Date 2024/7/25 下午7:33
 * @注释:
 **/
@Data
public class BorrowInfoDto {
    private Integer readerId;
    private Integer bookId;
}
