package org.example.dto;

import lombok.Data;

/**
 * 项目:firstObjectMaven
 * 描述: 统一响应类
 * 时间:2024/6/17 14:47
 * 作者:付庭喜
 * 版本:1.0
 **/
@Data
public class UserInfoDto {
    private String userName;
    private String sex;
    private String age;
}
