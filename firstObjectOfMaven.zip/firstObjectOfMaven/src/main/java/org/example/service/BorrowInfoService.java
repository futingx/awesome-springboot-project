package org.example.service;

import org.example.dto.BorrowInfoDto;
import org.example.pojo.BorrowInfo;
import org.example.util.ResultVo;

/**
 * @version 1.0
 * @Author 付庭喜
 * @Date 2024/7/18 上午10:21
 * {@code @注释:定义具体业务实现}
 **/
public interface BorrowInfoService {

    //新增用户功能
    ResultVo addBorrowInfo(BorrowInfo borrowInfo);

    //修改用户
    ResultVo updateBorrowInfo(BorrowInfo borrowInfo);

    //删除用户
    ResultVo deleteBorrowInfo(Integer id);

    //查询用户
    ResultVo query(BorrowInfoDto dto);

}
