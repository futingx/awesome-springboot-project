package org.example.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.api.R;
import org.example.dao.UserInfoDao;
import org.example.dto.UserInfoDto;
import org.example.pojo.UserInfo;
import org.example.service.UserInfoService;
import org.example.util.ResultVo;
import org.example.util.SHA3Util;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * 项目:firstObjectMaven
 * 描述: 统一响应类
 * 时间:2024/6/17 14:47
 * 作者:付庭喜
 * 版本:1.0
 **/
@Service
public class UserInfoServiceImpl implements UserInfoService {

    //获取userInfoDao的实现类对象
    @Resource
    UserInfoDao dao;

    @Override
    public ResultVo addUserInfo(UserInfo userInfo) {
        try {
            // 先加密生成颜值
            String salt = SHA3Util.generateRandomSalt(16);
            // 加密密码
            String pwd = SHA3Util.hashWithSalt(userInfo.getPassword(), salt);
            userInfo.setSalt(salt);
            userInfo.setPassword(pwd);

            // 新增用户信息
            int n = dao.insert(userInfo);
            if (n > 0) {
                return ResultVo.success("新增用户成功", null);
            } else {
                return ResultVo.error("新增用户失败", null);
            }
        } catch (Exception e) {
            e.printStackTrace();
            // 捕获异常，处理用户已存在的情况
            return ResultVo.error("用户已经存在，请重新输入", null);
        }
    }

    //修改
    @Override
    public ResultVo updateUserInfo(UserInfo userInfo) {
        try {
            // 先加密生成颜值
            String salt = SHA3Util.generateRandomSalt(16);
            // 加密密码
            String pwd = SHA3Util.hashWithSalt(userInfo.getPassword(), salt);
            userInfo.setSalt(salt);
            userInfo.setPassword(pwd);
            //修改
            int n = dao.updateById(userInfo);
            if (n > 0) {
                return ResultVo.success();
            }
            return ResultVo.error();
        }catch (Exception e){
            //e.printStackTrace();
            return ResultVo.error("用户已存在，请重新修改",null);
        }
    }

    @Override
    public ResultVo deleteUserInfo(Integer id) {
        int n = dao.deleteById(id);
        if (n > 0) {
            return ResultVo.success();
        }
        return ResultVo.error();
    }

    //查询
    @Override
    public ResultVo query(UserInfoDto dto) {
        QueryWrapper<UserInfo> queryWrapper = new QueryWrapper<>();

        //定义用户名的动态查询条件
        boolean isUserName = null!=dto.getUserName() && dto.getUserName().length()>0;
        queryWrapper.like(isUserName, "user_name",dto.getUserName());

        boolean isSex = null!=dto.getSex() && dto.getSex().length()>0;

        queryWrapper.eq(isSex,"sex",dto.getSex());
        List<UserInfo> list = dao.selectList(queryWrapper);
        if(null!=list && list.size()>0){
            return ResultVo.success("查询成功",list);
        }
        return ResultVo.error("查询失败",null);
    }

    //登录实现方法
    @Override
    public ResultVo login(UserInfo userInfo, HttpSession session) {

        QueryWrapper<UserInfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_name",userInfo.getUserName());
        UserInfo u = dao.selectOne(queryWrapper);
        if(u==null){
            return ResultVo.error("用户名不正确",null);
        }
        //加密密码
        String pwd = SHA3Util.hashWithSalt(userInfo.getPassword(),u.getSalt());
        queryWrapper.eq("password",pwd);
        UserInfo uu = dao.selectOne(queryWrapper);
        if(uu==null){
            return ResultVo.error("密码不正确",null);
        }
        //记录登录状态
        session.setAttribute("name",u.getUserName());
        System.out.println("密码正确");
        return ResultVo.success();
    }
}

