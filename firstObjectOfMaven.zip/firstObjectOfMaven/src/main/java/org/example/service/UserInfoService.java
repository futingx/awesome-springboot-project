package org.example.service;

import org.example.dto.UserInfoDto;
import org.example.pojo.UserInfo;
import org.example.util.ResultVo;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * 项目:firstObjectMaven
 * 描述: 统一响应类
 * 时间:2024/6/17 14:47
 * 作者:付庭喜
 * 版本:1.0
 **/
public interface UserInfoService {
    //新增用户
    ResultVo addUserInfo(UserInfo userInfo);

    //修改用户
    ResultVo updateUserInfo(UserInfo userInfo);

    //删除用户
    ResultVo deleteUserInfo(Integer id);

    //查询用户
    ResultVo query(UserInfoDto dto);

    //登录用户
    ResultVo login(UserInfo userInfo, HttpSession session);
}
