package org.example.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.example.dao.BorrowInfoDao;
import org.example.dao.BookInfoDao;

import org.example.dto.BorrowInfoDto;
import org.example.pojo.BookInfo;
import org.example.pojo.BorrowInfo;
import org.example.service.BorrowInfoService;
import org.example.util.ResultVo;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @version 1.0
 * @Author 付庭喜
 * @Date 2024/7/25 下午7:24
 * @注释:
 **/
@Service
public class BorrowInfoServiceImpl implements BorrowInfoService {
    //获取UserInfoDao的实现类对象
    @Resource//资源注入，通过dao来调用UserInfoDao中定义的方法从而实现于数据库的交互
            BorrowInfoDao dao;//定义的接口类对象
            BookInfoDao daoTwo;//定义的接口类对象
     // 添加构造函数，注入 daoTwo
    public BorrowInfoServiceImpl(BookInfoDao daoTwo) {
        this.daoTwo = daoTwo;
    }
    @Override//重写父类或接口中的同名方法
    public ResultVo addBorrowInfo(BorrowInfo borrowInfo) {
        try {

             //新增
            int n = dao.insert(borrowInfo);
            if (n > 0) {
                // 更新bookInfo表的available_copies字段
                BookInfo bookInfo = daoTwo.selectById(borrowInfo.getBookId());
                bookInfo.setAvailableCopies(bookInfo.getAvailableCopies() - 1);
                daoTwo.updateById(bookInfo);
                return ResultVo.success();
            } else {
                return ResultVo.error();
            }
        }catch (Exception e){
            //e.printStackTrace(); 打印堆栈
            System.out.println(e.getMessage());//看起来比较友好，也是打印异常
            return ResultVo.error("用户名重名","null");
        }

    }

    @Override//修改业务
    public ResultVo updateBorrowInfo(BorrowInfo borrowInfo) {
        try {

            int n = dao.updateById(borrowInfo);//updateById根据id进行修改
            if (n > 0) {
                //System.out.println("修改成功");
                return ResultVo.success();
            } else {
                //System.out.println("修改失败");
                return ResultVo.error();
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
            return ResultVo.error("用户名重名","null");
        }

    }

    @Override
public ResultVo deleteBorrowInfo(Integer id) {
    BorrowInfo borrowInfo = dao.selectById(id);
    int n = dao.deleteById(id);
    if (n > 0) {
        // 更新bookInfo表的available_copies字段
        BookInfo bookInfo = daoTwo.selectById(borrowInfo.getBookId());
        bookInfo.setAvailableCopies(bookInfo.getAvailableCopies() + 1);
        daoTwo.updateById(bookInfo);
        return ResultVo.success();
    } else {
        return ResultVo.error();
    }
}

    @Override
    public ResultVo query(BorrowInfoDto dto) {
        QueryWrapper<BorrowInfo> queryWrapper = new QueryWrapper<>();
        //定义读者Id
        boolean isreaderID = null!=dto.getReaderId()&&!dto.getReaderId().equals("");
        //根据isUserName的值，对user_name字段进行模糊查询。如果isUserName为true，则使用dto.getUserName()作为查询条件
        queryWrapper.like(isreaderID,"reader_id",dto.getReaderId());
        //定义图书ID查询
        boolean isbookID = null!=dto.getBookId()&&!dto.getBookId().equals("");
        queryWrapper.eq(isbookID,"book_id",dto.getBookId());

        List<BorrowInfo> list = dao.selectList(queryWrapper);
        if (list.size() > 0) {
            return ResultVo.success("查询到了数据", list);
        }
        return ResultVo.error("没有查询数据", null);
    }

}
