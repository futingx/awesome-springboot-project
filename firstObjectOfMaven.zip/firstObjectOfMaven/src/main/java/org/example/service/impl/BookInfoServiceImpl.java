package org.example.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.example.dao.BookInfoDao;
import org.example.dto.BookInfoDto;
import org.example.pojo.BookInfo;
import org.example.service.BookInfoService;
import org.example.util.ResultVo;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * 项目:firstObjectMaven
 * 描述: 统一响应类
 * 时间:2024/6/17 14:47
 * 作者:付庭喜
 * 版本:1.0
 **/
@Service
public class BookInfoServiceImpl implements BookInfoService {

     //获取bookInfoDao的实现类对象
     @Resource
     BookInfoDao dao;

    @Override
    public ResultVo addBookInfo(BookInfo bookInfo) {
        //1.验证用户名是否唯一
        try{
            int n = dao.insert(bookInfo);
            if (n > 0) {
                return ResultVo.success("新增用户成功",null);
            }
            return ResultVo.error("新增用户失败",null);
        }catch (Exception e){
            //System.out.println(e.getMessage());
            return ResultVo.error("用户已经存在,请重新输入",null);
        }
    }

    //修改
    @Override
    public ResultVo updateBookInfo(BookInfo bookInfo) {
       try {
            //修改
            int n = dao.updateById(bookInfo);
            if (n > 0) {
                return ResultVo.success();
            }
            return ResultVo.error();
       }catch (Exception e){
            //e.printStackTrace();
            return ResultVo.error("用户已存在，请重新修改",null);
       }
    }

    @Override
    public ResultVo deleteBookInfo(Integer id) {
        int n = dao.deleteById(id);
        if (n > 0) {
            return ResultVo.success();
        }
        return ResultVo.error();
    }

    //查询
    @Override
    public ResultVo query(BookInfoDto dto) {
        QueryWrapper<BookInfo> queryWrapper = new QueryWrapper<>();

        //定义用户名的动态查询条件
        boolean isTitle = null!=dto.getTitle() && dto.getTitle().length()>0;
        queryWrapper.like(isTitle, "title",dto.getTitle());

        boolean isAuthor = null!=dto.getAuthor() && dto.getAuthor().length()>0;
        queryWrapper.eq(isAuthor,"author",dto.getAuthor());

        boolean isPublisher = null!=dto.getAuthor() && dto.getAuthor().length()>0;
        queryWrapper.eq(isPublisher,"publisher",dto.getPublisher());

        List<BookInfo> list = dao.selectList(queryWrapper);
        if(null!=list && list.size()>0){
            return ResultVo.success("查询成功",list);
        }
        return ResultVo.error("查询失败",null);
    }
}

