package org.example.service;

import org.example.dto.BookInfoDto;
import org.example.pojo.BookInfo;
import org.example.util.ResultVo;

import javax.annotation.Resource;

/**
 * 项目:firstObjectMaven
 * 描述: 统一响应类
 * 时间:2024/6/17 14:47
 * 作者:付庭喜
 * 版本:1.0
 **/
public interface BookInfoService {
    //新增用户
    ResultVo addBookInfo(BookInfo bookInfo);

    //修改用户
    ResultVo updateBookInfo(BookInfo bookInfo);

    //删除用户
    ResultVo deleteBookInfo(Integer id);

    //查询用户
    ResultVo query(BookInfoDto dto);
}
