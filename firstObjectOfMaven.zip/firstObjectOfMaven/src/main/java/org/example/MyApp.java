package org.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//springboot项目的启动类,之后启动这个SpringBoot项目都在这里启动
@SpringBootApplication
public class MyApp {
    public static void main(String[] args) {
        //启动服务器
        SpringApplication.run(MyApp.class,args);
    }
}
