package org.example.util;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * 项目:yunnanmd
 * 描述:
 * 时间:2024/7/25 10:20
 * 作者:admin
 * 版本:1.0
 **/
//如果不想加拦截器可以把这个注解注释掉
//@Configuration
public class MyInterceptorConfig implements WebMvcConfigurer {

    @Override
    public void addInterceptors(InterceptorRegistry registry) {

        registry.addInterceptor(new MyInterceptor()).addPathPatterns("/html/*.html").excludePathPatterns("/html/login.html").excludePathPatterns("/userInfo/login");
    }
}
