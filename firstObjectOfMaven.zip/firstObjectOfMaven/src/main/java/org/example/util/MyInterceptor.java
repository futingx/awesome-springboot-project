package org.example.util;

import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * 项目:yunnanmd
 * 描述: 登录校验
 * 时间:2024/7/25 10:05
 * 作者:admin
 * 版本:1.0
 **/
public class MyInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        //获取session对象
        HttpSession session = request.getSession();
        //获取登录状态
        Object obj = session.getAttribute("name");
        if(obj==null){
            System.out.println("用户没有登录");
            //回到登录页面
            request.getRequestDispatcher("/html/login.html").forward(request,response);
            return false;
        }
        //放行
        System.out.println("用户放行");
        return true;
    }
}
