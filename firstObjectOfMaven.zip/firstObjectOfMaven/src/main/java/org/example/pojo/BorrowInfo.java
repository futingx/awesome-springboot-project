package org.example.pojo;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

/**
 * @version 1.0
 * @Author 付庭喜
 * @Date 2024/7/25 下午6:48
 * @注释:
 **/
@Data
@TableName("borrow")
public class BorrowInfo {
    @TableId(value = "borrow_id",type = IdType.AUTO)
    private Integer borrowId;

    @TableField("book_id")
    private Integer bookId;  // 外键关联到 bookInfo 表的主键


    private Integer readerId;
    private String borrowDate;
    private String dueDate;

    //逻辑删除
    @TableLogic
    private Integer deleteTag;
}
