package org.example.pojo;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

@Data
@TableName("book_info")  //放数据库中要操作的表的名称
public class BookInfo {
    //主键
    @TableId(value = "book_id",type = IdType.AUTO)
    private Integer bookId; //首字母小写，之后的第一个单词的每个首字母大写（驼峰式命名）

    //非主键
    private String title;
    private String author;
    private String publisher;
    private String publicationYear;
    private String genre;
    private  Integer totalCopies;
    private  String description;
    private Integer availableCopies;
//    @TableField("available_copies")
//    private Integer availableCopies;

    //逻辑删除
    @TableLogic
    private Integer deleteTag;

}
