package org.example.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
//JavaBean类 获取和设置get和set方法或@data
//注解都与表有关系
@TableName("user_info") //括号填表名
public class UserInfo {
    //主键
    @TableId(value = "user_id",type = IdType.AUTO)//type指的是主键生成策略
    private Integer userId; //首字母小写，第二个首字母大写（当有两个单词时）

    //非主键 可省略注解
    private String userName;
    private Integer age;
    private String sex;
    private  String password;
    private  String salt;
    private String contacting;
    private String borrowRecords;
    private  String breachRecords;

    //逻辑删除
    @TableLogic
    private  Integer deleteTag;

}
