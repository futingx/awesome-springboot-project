package org.example.controller;

import org.example.pojo.BookInfo;
import org.example.pojo.UserInfo;
import org.example.util.ResultVo;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
/**
 * 项目:firstObjectMaven
 * 描述: 测试控制器类
 * 时间:2024/6/17 14:47
 * 作者:付庭喜
 * 版本:1.0
 **/

@RequestMapping("/test")//地址映射
@RestController//表示这是一个控制器类，并且TestController类的new操作不需要我们再写了
public class TestController {

    //测试方法
    @RequestMapping("/test01")
    public ResultVo test(UserInfo userInfo){
        return ResultVo.success( "登陆失败","我叫"+userInfo.getUserName()+"今年"+userInfo.getAge()+"岁");
    }

}
