package org.example.controller;

import org.example.dto.BorrowInfoDto;
import org.example.pojo.BorrowInfo;
import org.example.service.BorrowInfoService;
import org.example.util.ResultVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("/borrowInfo")
@RestController
public class BorrowInfoController {
    //获取UserInfoService的实现类对象
    @Autowired
    BorrowInfoService service;

    @RequestMapping("/add")
    public ResultVo add(BorrowInfo borrowInfo){  //做统一的封装处理ResultVo
        return service.addBorrowInfo(borrowInfo);
    }

    @RequestMapping("/update")
    public ResultVo update(BorrowInfo borrowInfo){  //做统一的封装处理ResultVo
        return service.updateBorrowInfo(borrowInfo);
    }

    @RequestMapping("/del")
    public ResultVo del(Integer id){  //做统一的封装处理ResultVo
        return service.deleteBorrowInfo(id);
    }

    @RequestMapping("/query")
    public ResultVo query(BorrowInfoDto dto){  //做统一的封装处理ResultVo
        return service.query(dto);
    }

}
