package org.example.controller;

import org.example.dto.UserInfoDto;
import org.example.pojo.UserInfo;
import org.example.service.UserInfoService;
import org.example.util.ResultVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;

/**
 * 项目:firstObjectMaven
 * 描述: 统一响应类
 * 时间:2024/6/17 14:47
 * 作者:付庭喜
 * 版本:1.0
 **/
@RequestMapping("/userInfo")//地址映射
@RestController//表示这是一个控制器类，并且TestController类的new操作不需要我们再写了
public class UserInfoController {
    //UserInfoService的实现类对象
    @Autowired
    UserInfoService service;

    @RequestMapping("/add")
    public ResultVo add(UserInfo userInfo) {
        return service.addUserInfo(userInfo);
    }

    @RequestMapping("/update")
    public ResultVo update(UserInfo userInfo) {
        return service.updateUserInfo(userInfo);
    }
    @RequestMapping("/delete")
    public ResultVo delete(Integer id) {
        return service.deleteUserInfo(id);
    }
    @RequestMapping("/query")
    public ResultVo query(UserInfoDto dto) {
        return service.query(dto);
    }
    @RequestMapping("/login")
    public ResultVo login(UserInfo userInfo,HttpSession session) {
        return service.login(userInfo,session);
    }
}
