	
			//设置cookie的函数
			function setCookie(name,v,day){
				//创建时间对象
				var time = new Date();
				//设置失效时间
				time.setTime(time.getTime() +(day*24*60*60*1000));
				//设置cookei
				document.cookie = name+"="+v+"; expires="+time.toGMTString();
			}
			
			//获取cookie的函数
			function getCookie(name){
				var v = document.cookie;
				//根据分号分割
				var arrc = v.split(";");
				console.log(arrc);
				for(var i=0;i<arrc.length;i++){
					//去除空格
					arrc[i] = arrc[i].trim();
					//判断获取那个键名
					if(arrc[i].indexOf(name)==0){
						//计算=的索引号
						var index = arrc[i].indexOf("=");
						var v = arrc[i].substring(index+1,arrc[i].length);
				
						return v;
					}
				
				}
				//考虑 键名不对或者cookie 失效就返回的空字符串
				return "";
			
			}
			
			///删除
			function delCookie(name){
				//创建时间
				var time = new Date();
				//设置过期时间
				time.setFullYear(2000,12,10);
				//设置cookie的过期时间小于今年，就是删除
				document.cookie = name+"=; expires="+time.toGMTString();
				
			}
