
    new Vue({
        el:"#myApp02",
        data:{
            //封装起来这里只列举两个参数title,author,publisher,publisherYear
            bookInfoParameter:{//查询参数
                title:"",
                author:"",
                publisher:"",
                publicationYear:""
            },
            addForm:{
                //新增表单对象
                title:"",
                author:"",
                publisher:"",
                publicationYear:"",
                genre:""
            },
            updateForm:{
                //新增表单对象
                bookId:" ",
                title:"",
                author:"",
                publisher:"",
                publicationYear:"",
                genre:""
            },
            list:[],//表格数组()
            addShow:false,//弹窗新增显示
            updateShow:false//更新用户
        },
        methods:{
            //定义函数
            update(x){
                //打开修改表单弹窗
                //数据回显实现
                this.updateForm = x;
                //打开弹窗
                this.updateShow = true;
            },
            updateUser(){
                //保存修改后的用户信息
                const self=this;
                $.ajax({
                    url:"/book/update",//后端请求控制类地址
                    data:this.updateForm,//接口测试工具当中的参数（上面封装好的)
                    type:"get",//请求的方式是GET,默认是get可以省略
                    success:function (rs) {
                        //访问后端成功后执行的函数(url,data,type都没问题)
                        console.log(rs);//用来做代码调试
                        alert(rs.msg);
                        if(rs.code==200){
                            //刷新数据
                            self.queryData();
                            //关闭修改弹窗
                            self.updateShow = false;
                        }
                    },
                    error:function (rs) {
                        //可以省略
                        //访问后端失败后执行的函数(url,data,type都没问题)
                        console.log(rs);
                    }
                })
            },
            saveUser(){
                const self=this;
                //保存用户
                $.ajax({
                    url:"/book/add",//后端请求控制类地址
                    data:this.addForm,//接口测试工具当中的参数（上面封装好的)
                    type:"get",//请求的方式是GET,默认是get可以省略
                    success:function (rs) {
                        //访问后端成功后执行的函数(url,data,type都没问题)
                        console.log(rs);//用来做代码调试
                        alert(rs.msg);
                        if(rs.code==200){
                            //刷新数据
                            self.queryData();
                            //关闭新增弹窗
                            self.addShow = false;
                        }
                    },
                    error:function (rs) {
                        //可以省略
                        //访问后端失败后执行的函数(url,data,type都没问题)
                        console.log(rs);
                    }
                })
            },
            addUser(){
                //新增用户
                this.addShow=true;
            },
            del(x){
                //删除用户方法
                //定义一个确定框
                const is = confirm("是否删除");
                if(is==true){
                    $.ajax({
                    url:"/book/delete",//后端请求控制类地址
                    data: {
                          "id":x.bookId,
                        },
                    type:"get",//请求的方式是GET,默认是get可以省略
                    success:function (rs) {
                        //访问后端成功后执行的函数(url,data,type都没问题)
                        console.log(rs);//用来做代码调试
                        if(rs.code==200){
                            //刷新数据
                            self.queryData();
                        }
                    },
                    error:function (rs) {
                        //可以省略
                        //访问后端失败后执行的函数(url,data,type都没问题)
                        console.log(rs);
                    }

                })
                }
            },
            reset(){
                //重置
                this.bookInfoParameter.title="";
                this.bookInfoParameter.author="";
                this.bookInfoParameter.publisher="";
                this.bookInfoParameter.publicationYear="";
                this.queryData();
            },
            queryData(){
                const self=this;//vue对象传给self
                //查询用户发送ajax(jquery当中的)请求
                $.ajax({
                    url:"/book/query",//后端请求控制类地址
                    data:this.bookInfoParameter,//接口测试工具当中的参数（上面封装好的)
                    type:"get",//请求的方式是GET,默认是get可以省略
                    success:function (rs) {
                        //访问后端成功后执行的函数(url,data,type都没问题)
                        console.log(rs);//用来做代码调试
                        if(rs.code==200){
                            self.list = rs.data;
                        }
                        else{
                            //清空数组
                            self.list=[];
                            alert(rs.msg);
                        }
                    },
                    error:function (rs) {
                        //可以省略
                        //访问后端失败后执行的函数(url,data,type都没问题)
                        console.log(rs);
                    }

                })

            }
        },
        //生命周期函数,当我们加载完页面和js之后开始执行的函数
        mounted(){
            //运行查询函数
            this.queryData();
        }

    })
