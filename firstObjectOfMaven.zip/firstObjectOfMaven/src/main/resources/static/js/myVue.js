	/* 定义全局组件 */
	/* 自定义组件名称命名不支持大写字符，多个单词 用 - 分割开 */
	 Vue.component("my-head",{
		 template:'<h1>标题</h1>'
	 })