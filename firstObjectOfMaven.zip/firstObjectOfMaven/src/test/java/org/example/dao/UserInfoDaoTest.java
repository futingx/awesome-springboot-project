package org.example.dao;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.example.MyApp;
import org.example.pojo.BookInfo;
import org.example.pojo.UserInfo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.util.List;

/**
 * 项目:firstObjectMaven
 * 描述: 统一响应类
 * 时间:2024/6/17 14:47
 * 作者:付庭喜
 * 版本:1.0
 **/
@RunWith(SpringRunner.class)//spring测试的运行器注解
@SpringBootTest(classes = MyApp.class) //springboot测试类注解

public class UserInfoDaoTest {

    //获取userInfoDao的实现类对象
    @Resource
    UserInfoDao dao;

    //查询，实际业务用的最多
    @Test
    public void query() {
        dao.selectList(null);
    }
    //新增
    @Test
    public void add() {
        UserInfo user = new UserInfo();
        user.setUserName("LL");
        user.setAge("18");
        user.setSex("男");

        int n = dao.insert(user);
        if (n > 0) {
            System.out.println("成功");
        }
    }
    //更新
    @Test
    public void update() {
        UserInfo user = new UserInfo();
        user.setUserId(3);
        user.setUserName("WW");

        int n = dao.updateById(user);
        if (n > 0) {
            System.out.println("成功");
        }
    }

    //删除，一般情况不做物理删除,用逻辑删除
    @Test
    public void delete() {
     int n = dao.deleteById(1);
        if (n > 0) {
            System.out.println("删除成功");
        }
    }

    @Test
       //条件查询-精确查询
    public void condition(){
        //查询用户名是ftx的用户
        //构造条件构造器
        QueryWrapper<UserInfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_name", "ftx");
        List<UserInfo> list = dao.selectList(queryWrapper);
        UserInfo userInfo = dao.selectOne(queryWrapper);//查询一条数据
    }

    @Test
    //条件查询-模糊查询一般情况是包含某个内容的数据段
    public void like(){
        //查询用户名是F的用户
        //构造条件构造器
        QueryWrapper<UserInfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.like("user_name", "F");
        queryWrapper.eq("sex","女");
        List<UserInfo> list = dao.selectList(queryWrapper);
        //UserInfo userInfo = dao.selectOne(queryWrapper);//查询一条数据
    }
}