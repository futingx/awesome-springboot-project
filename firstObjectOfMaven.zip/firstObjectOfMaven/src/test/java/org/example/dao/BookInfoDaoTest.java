package org.example.dao;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.example.MyApp;
import org.example.pojo.BookInfo;
import org.example.pojo.UserInfo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;

import java.awt.print.Book;
import java.util.List;

import static org.junit.Assert.*;

/**
 * 项目:firstObjectMaven
 * 描述: 统一响应类
 * 时间:2024/6/17 14:47
 * 作者:付庭喜
 * 版本:1.0
 **/
@RunWith(SpringRunner.class)//spring测试的运行器注解
@SpringBootTest(classes = MyApp.class) //springboot测试类注解
public class BookInfoDaoTest {
    //获取userInfoDao的实现类对象
    @Resource
    BookInfoDao dao;

    @Test
    public void query() {
        dao.selectList(null);
    }

    @Test
    public void add() {
        BookInfo book = new BookInfo();
        //book.setBookId(1);
        book.setTitle("科技");
        book.setAuthor("FTX");
        book.setDescription("FTX");
        book.setGenre("FTX");
        book.setPublisher("FTX");
        book.setAvailableCopies(10);
        book.setPublicationYear("FTX");
        book.setTotalCopies(10);

        int n = dao.insert(book);
        if(n>0)
        {
            System.out.println("成功");
        }
        else System.out.println("失败");
    }

    @Test
    public void update() {
    }

    @Test
    public void delete() {
    }




}